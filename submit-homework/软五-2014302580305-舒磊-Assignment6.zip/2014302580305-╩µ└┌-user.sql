CREATE TABLE `user`.`2014302580305_user` (
  `id` INT NOT NULL,
  `password` VARCHAR(45) NULL,
  `money` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

public class Login {

	private JFrame frame;
	private JFrame frame2;
	private JTextField textField;
	private JTextField textField_1;
	private JPasswordField passWordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		User user = new User();
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(89, 26, 245, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		passWordField = new JPasswordField();
		passWordField.setBounds(89, 82, 245, 21);
		frame.getContentPane().add(passWordField);
		passWordField.setColumns(10);
		
		
		
		JButton button = new JButton("\u767B\u5F55");
		button.setBounds(162, 139, 93, 23);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(user.checkid(textField.getText(),textField_1.getText())) {
					//��ת
					frame.dispose();
					frame2.setVisible(true);
				}
				else {
					Toolkit.getDefaultToolkit().beep();
					JOptionPane.showMessageDialog(null, "�û���Ϣ����", null,JOptionPane.PLAIN_MESSAGE);
				}
			}
		});
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("\u6CE8\u518C");
		button_1.setBounds(162, 177, 93, 23);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				user.checkregister(textField.getText(),textField_1.getText());
				//Toolkit.getDefaultToolkit().beep();
				//JOptionPane.showMessageDialog(null, "ע��ɹ���", null,JOptionPane.PLAIN_MESSAGE);

			}
		});
		frame.getContentPane().add(button_1);
		
		JLabel lblId = new JLabel("    id\uFF1A");
		lblId.setBounds(21, 28, 53, 19);
		frame.getContentPane().add(lblId);
		
		JLabel label = new JLabel("   \u5BC6\u7801\uFF1A");
		label.setBounds(21, 86, 54, 15);
		frame.getContentPane().add(label);
		
		
		
		ShoppingCar car = new ShoppingCar();
		frame2 = new JFrame();
		frame2.getContentPane().setBackground(new Color(240, 240, 240));
		frame2.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("+");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				car.addpet(1);
			}
		});
		btnNewButton.setBounds(170, 10, 42, 37);
		frame2.getContentPane().add(btnNewButton);
		
		JButton button1 = new JButton("-");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(1);
			}
		});
		button1.setBounds(170, 73, 42, 37);
		frame2.getContentPane().add(button1);
		
		JButton button_11 = new JButton("+");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(2);
			}
		});
		button_11.setBounds(422, 10, 42, 37);
		frame2.getContentPane().add(button_11);
		
		JButton button_2 = new JButton("-");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(2);
			}
		});
		button_2.setBounds(422, 73, 42, 37);
		frame2.getContentPane().add(button_2);
		
		JButton button_3 = new JButton("+");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(3);
			}
		});
		button_3.setBounds(700, 10, 42, 37);
		frame2.getContentPane().add(button_3);
		
		JButton button_4 = new JButton("-");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(3);
			}
		});
		button_4.setBounds(700, 73, 42, 37);
		frame2.getContentPane().add(button_4);
		
		JButton button_5 = new JButton("+");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(4);
			}
		});
		button_5.setBounds(170, 156, 42, 37);
		frame2.getContentPane().add(button_5);
		
		JButton button_6 = new JButton("+");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(5);
			}
		});
		button_6.setBounds(422, 156, 42, 37);
		frame2.getContentPane().add(button_6);
		
		JButton button_7 = new JButton("+");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(6);
			}
		});
		button_7.setBounds(700, 156, 42, 37);
		frame2.getContentPane().add(button_7);
		
		JButton button_8 = new JButton("+");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(7);
			}
		});
		button_8.setBounds(170, 298, 42, 37);
		frame2.getContentPane().add(button_8);
		
		JButton button_9 = new JButton("+");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(8);
			}
		});
		button_9.setBounds(422, 298, 42, 37);
		frame2.getContentPane().add(button_9);
		
		JButton button_10 = new JButton("+");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(9);
			}
		});
		button_10.setBounds(700, 298, 42, 37);
		frame2.getContentPane().add(button_10);
		
		JButton button_111 = new JButton("+");
		button_111.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(10);
			}
		});
		button_111.setBounds(170, 447, 42, 37);
		frame2.getContentPane().add(button_111);
		
		JButton button_12 = new JButton("+");
		button_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(11);
			}
		});
		button_12.setBounds(422, 447, 42, 37);
		frame2.getContentPane().add(button_12);
		
		JButton button_13 = new JButton("+");
		button_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.addpet(12);
			}
		});
		button_13.setBounds(700, 447, 42, 37);
		frame2.getContentPane().add(button_13);
		
		JButton button_14 = new JButton("-");
		button_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(4);
			}
		});
		button_14.setBounds(170, 219, 42, 37);
		frame2.getContentPane().add(button_14);
		
		JButton button_15 = new JButton("-");
		button_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(5);
			}
		});
		button_15.setBounds(422, 219, 42, 37);
		frame2.getContentPane().add(button_15);
		
		JButton button_16 = new JButton("-");
		button_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(6);
			}
		});
		button_16.setBounds(700, 219, 42, 37);
		frame2.getContentPane().add(button_16);
		
		JButton button_17 = new JButton("-");
		button_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(7);
			}
		});
		button_17.setBounds(170, 366, 42, 37);
		frame2.getContentPane().add(button_17);
		
		JButton button_18 = new JButton("-");
		button_18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(8);
			}
		});
		button_18.setBounds(422, 366, 42, 37);
		frame2.getContentPane().add(button_18);
		
		JButton button_19 = new JButton("-");
		button_19.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(9);
			}
		});
		button_19.setBounds(700, 366, 42, 37);
		frame2.getContentPane().add(button_19);
		
		JButton button_20 = new JButton("-");
		button_20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(10);
			}
		});
		button_20.setBounds(170, 510, 42, 37);
		frame2.getContentPane().add(button_20);
		
		JButton button_21 = new JButton("-");
		button_21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(11);
			}
		});
		button_21.setBounds(422, 510, 42, 37);
		frame2.getContentPane().add(button_21);
		
		JButton button_22 = new JButton("-");
		button_22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				car.reducepet(12);
			}
		});
		button_22.setBounds(700, 510, 42, 37);
		frame2.getContentPane().add(button_22);
		
		JButton btnNewButton_1 = new JButton("\u8D2D\u4E70");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int bill = car.getcount();
				user.add(10000);
				user.save();
				if (bill<user.getmoney()) {
					user.reduce(bill);
					user.save();
					Toolkit.getDefaultToolkit().beep();
					JOptionPane.showMessageDialog(null, "����ɹ���", null,JOptionPane.PLAIN_MESSAGE);
				}
				else {
					Toolkit.getDefaultToolkit().beep();
					JOptionPane.showMessageDialog(null, "���㣡", null,JOptionPane.PLAIN_MESSAGE);
				}
				
			}
		});
		btnNewButton_1.setBounds(319, 580, 93, 23);
		frame2.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\dog.jpg"));
		lblNewLabel.setBounds(59, 10, 101, 100);
		frame2.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\cat.jpg"));
		lblNewLabel_1.setBounds(311, 10, 101, 100);
		frame2.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\turtle.jpg"));
		lblNewLabel_2.setBounds(586, 10, 101, 100);
		frame2.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\parrot.jpg"));
		lblNewLabel_3.setBounds(59, 156, 101, 100);
		frame2.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\hamester.jpg"));
		lblNewLabel_4.setBounds(312, 156, 100, 100);
		frame2.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("New label");
		lblNewLabel_5.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\squirrel.jpg"));
		lblNewLabel_5.setBounds(586, 156, 101, 100);
		frame2.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("New label");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\rabbit.jpg"));
		lblNewLabel_6.setBounds(59, 298, 101, 100);
		frame2.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("New label");
		lblNewLabel_7.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\snake.jpg"));
		lblNewLabel_7.setBounds(312, 298, 100, 100);
		frame2.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("New label");
		lblNewLabel_8.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\lizard.jpg"));
		lblNewLabel_8.setBounds(586, 298, 101, 100);
		frame2.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("New label");
		lblNewLabel_9.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\fish.jpg"));
		lblNewLabel_9.setBounds(59, 447, 101, 100);
		frame2.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("New label");
		lblNewLabel_10.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\myna.jpg"));
		lblNewLabel_10.setBounds(312, 447, 100, 100);
		frame2.getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("New label");
		lblNewLabel_11.setIcon(new ImageIcon("C:\\Users\\SPQ\\workspace\\PetMarket\\src\\imgs\\canary.jpg"));
		lblNewLabel_11.setBounds(586, 447, 101, 100);
		frame2.getContentPane().add(lblNewLabel_11);
		
		JLabel label1 = new JLabel("$100");
		label1.setBounds(83, 120, 54, 15);
		frame2.getContentPane().add(label1);
		
		JLabel lblNewLabel_12 = new JLabel("$150");
		lblNewLabel_12.setBounds(336, 120, 54, 15);
		frame2.getContentPane().add(lblNewLabel_12);
		
		JLabel label_1 = new JLabel("$150");
		label_1.setBounds(610, 120, 54, 15);
		frame2.getContentPane().add(label_1);
		
		JLabel lblNewLabel_13 = new JLabel("$100");
		lblNewLabel_13.setBounds(83, 266, 54, 15);
		frame2.getContentPane().add(lblNewLabel_13);
		
		JLabel label_2 = new JLabel("$200");
		label_2.setBounds(336, 266, 54, 15);
		frame2.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("$300");
		label_3.setBounds(610, 266, 54, 15);
		frame2.getContentPane().add(label_3);
		
		JLabel label_4 = new JLabel("$350");
		label_4.setBounds(83, 409, 54, 15);
		frame2.getContentPane().add(label_4);
		
		JLabel label_5 = new JLabel("$150");
		label_5.setBounds(336, 409, 54, 15);
		frame2.getContentPane().add(label_5);
		
		JLabel label_6 = new JLabel("$200");
		label_6.setBounds(610, 408, 54, 15);
		frame2.getContentPane().add(label_6);
		
		JLabel label_7 = new JLabel("$100");
		label_7.setBounds(83, 557, 54, 15);
		frame2.getContentPane().add(label_7);
		
		JLabel label_8 = new JLabel("$250");
		label_8.setBounds(336, 555, 54, 15);
		frame2.getContentPane().add(label_8);
		
		JLabel label_9 = new JLabel("$300");
		label_9.setBounds(610, 557, 54, 15);
		frame2.getContentPane().add(label_9);
		frame2.setBounds(100, 100, 892, 851);
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

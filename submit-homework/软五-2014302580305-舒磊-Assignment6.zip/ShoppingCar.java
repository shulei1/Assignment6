import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

public class ShoppingCar {
	//�����嵥
	ArrayList list = new ArrayList();
	//������Ʒ
	public void addpet(int id) {
		list.add(id);
	}
	//�޳���Ʒ
	public void reducepet(int id) {
		Iterator<Integer> iterator = list.iterator();  
		while(iterator.hasNext()){  
		    int i = iterator.next();  
		    if(i == id){  
		        iterator.remove();  
		    }  
		}
	}
	public int getcount() {
		int count = 0;
		Iterator<Integer> iterator = list.iterator();  
		while(iterator.hasNext()){  
		    int i = iterator.next();  
		    try {
				Connection conn;
				Statement stmt;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery("select id,sale from 2014302580205_pet");
				while (rs.next()) {
					if (i == rs.getInt(0)) {
						count = count + rs.getInt(1);
					}
				}
			}
			catch (Exception ex) {
			}
		}
		return count;
	}
}

import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class User {
	String id;
	String password;
	int money = 0;
	String email;
	public void setId(String a) {
		id = a;
	}
	public void setPassword(String a) {
		password = a;
	}
	public void setEmail(String a) {
		email = a;
	}
	public void add(int a) {
		money = money + a;
	}
	public void reduce(int a) {
		money = money - a; 
	}
	public int getmoney() {
		return money;
	}
	public void save() {
		try {
			Connection conn;
			Statement stmt;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select id,money from 2014302580205_user");
			while (rs.next()) {
				if (id == rs.getString(0)) {
					stmt.executeUpdate("update 2014302580305_user set money='"+money+"' where id='"+id+"");
				}
			}
		}
		catch (Exception ex) {
		}
	}
	public void register() {
		try {
			Connection conn;
			Statement stmt;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			stmt = conn.createStatement();
			stmt.executeUpdate("Insert into 2014302580205_user(id,password,money) values('"+id+"','"+password+"','"+money+"')");
		}
		catch (Exception ex) {
		}
	}
	public boolean checkid(String a,String b) {
		boolean result = false;
		try {
			Connection conn;
			Statement stmt;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select id from 2014302580205_user");
			while (rs.next()) {
				if (a == rs.getString(0)) {
					result = checkpassword(b);//���ü������뺯��
				}
				else {
					result = false;
				}
			}
		}
		catch (Exception ex) {
		}
		return result;
	}
	public boolean checkpassword(String a) {
		boolean result = false;
		try {
			Connection conn;
			Statement stmt;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select password from 2014302580205_user");
			while (rs.next()) {
				if (a == rs.getString(0)) {
					result = true;
				}
				else {
					result = false;
				}
			}
		}
		catch (Exception ex) {
		}
		return result;
	}
	public void checkregister(String a,String b) {
		try {
			Connection conn;
			Statement stmt;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select id from 2014302580205_user");
			while (rs.next()) {
				if (a == rs.getString(0)) {
					Toolkit.getDefaultToolkit().beep();
					JOptionPane.showMessageDialog(null, "�û�id�Ѵ��ڣ�", null,JOptionPane.PLAIN_MESSAGE);
				}
				else {
					setId(a);
					setPassword(b);
					register();
					Toolkit.getDefaultToolkit().beep();
					JOptionPane.showMessageDialog(null, "ע��ɹ���", null,JOptionPane.PLAIN_MESSAGE);
				}
			}
		}
		catch (Exception ex) {
		}
	}
}
